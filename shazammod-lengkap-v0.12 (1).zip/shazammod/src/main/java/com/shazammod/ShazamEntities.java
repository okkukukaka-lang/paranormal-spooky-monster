package com.shazammod;

import com.shazammod.guardian.EarthGolem;
import com.shazammod.guardian.JungleBrute;
import com.shazammod.guardian.MercurySpirit;
import com.shazammod.guardian.ScholarIllusion;
import com.shazammod.guardian.ScholarZombie;
import com.shazammod.guardian.StormStalker;
import com.shazammod.guardian.UndeadGladiator;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Jenis entity enam penjaga kuil (plus bayangan Scholar). */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ShazamEntities {
    private ShazamEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ShazamMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<ScholarZombie>> SCHOLAR_ZOMBIE = ENTITY_TYPES.register(
            "scholar_zombie", () -> EntityType.Builder.of(ScholarZombie::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.95f).eyeHeight(1.74f).clientTrackingRange(10).build("scholar_zombie"));

    public static final DeferredHolder<EntityType<?>, EntityType<ScholarIllusion>> SCHOLAR_ILLUSION = ENTITY_TYPES.register(
            "scholar_illusion", () -> EntityType.Builder.of(ScholarIllusion::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.95f).eyeHeight(1.74f).clientTrackingRange(10).build("scholar_illusion"));

    public static final DeferredHolder<EntityType<?>, EntityType<JungleBrute>> JUNGLE_BRUTE = ENTITY_TYPES.register(
            "jungle_brute", () -> EntityType.Builder.of(JungleBrute::new, MobCategory.MONSTER)
                    .sized(1.95f, 2.2f).clientTrackingRange(10).build("jungle_brute"));

    public static final DeferredHolder<EntityType<?>, EntityType<EarthGolem>> EARTH_GOLEM = ENTITY_TYPES.register(
            "earth_golem", () -> EntityType.Builder.of(EarthGolem::new, MobCategory.MONSTER)
                    .sized(1.4f, 2.7f).clientTrackingRange(10).build("earth_golem"));

    public static final DeferredHolder<EntityType<?>, EntityType<StormStalker>> STORM_STALKER = ENTITY_TYPES.register(
            "storm_stalker", () -> EntityType.Builder.of(StormStalker::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.77f).eyeHeight(1.3452f).clientTrackingRange(10).build("storm_stalker"));

    public static final DeferredHolder<EntityType<?>, EntityType<UndeadGladiator>> UNDEAD_GLADIATOR = ENTITY_TYPES.register(
            "undead_gladiator", () -> EntityType.Builder.of(UndeadGladiator::new, MobCategory.MONSTER)
                    .fireImmune().sized(0.7f, 2.4f).eyeHeight(2.1f).clientTrackingRange(10).build("undead_gladiator"));

    public static final DeferredHolder<EntityType<?>, EntityType<MercurySpirit>> MERCURY_SPIRIT = ENTITY_TYPES.register(
            "mercury_spirit", () -> EntityType.Builder.of(MercurySpirit::new, MobCategory.MONSTER)
                    .sized(0.35f, 0.6f).eyeHeight(0.36f).clientTrackingRange(10).updateInterval(2).build("mercury_spirit"));

    public static final DeferredHolder<EntityType<?>, EntityType<MagicBolt>> MAGIC_BOLT = ENTITY_TYPES.register(
            "magic_bolt", () -> EntityType.Builder.<MagicBolt>of(MagicBolt::new, MobCategory.MISC)
                    .noSave().sized(0.0f, 0.0f).clientTrackingRange(16).updateInterval(Integer.MAX_VALUE).build("magic_bolt"));

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(SCHOLAR_ZOMBIE.get(), ScholarZombie.createAttributes().build());
        event.put(SCHOLAR_ILLUSION.get(), ScholarIllusion.createAttributes().build());
        event.put(JUNGLE_BRUTE.get(), JungleBrute.createAttributes().build());
        event.put(EARTH_GOLEM.get(), EarthGolem.createAttributes().build());
        event.put(STORM_STALKER.get(), StormStalker.createAttributes().build());
        event.put(UNDEAD_GLADIATOR.get(), UndeadGladiator.createAttributes().build());
        event.put(MERCURY_SPIRIT.get(), MercurySpirit.createAttributes().build());
    }
}
