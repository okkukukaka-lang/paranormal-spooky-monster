package com.shazammod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.util.Mth;

/**
 * unlocked    = sudah layak jadi Shazam (nanti dibuka setelah boss kalah, sementara lewat /shazam unlock)
 * transformed = sedang dalam wujud Shazam
 * energy      = Energi Petir, 0 sampai MAX_ENERGY
 * hoodUp      = hood jubah sedang dipakai di kepala
 */
public record ShazamData(boolean unlocked, boolean transformed, float energy, boolean hoodUp) {
    public static final ShazamData DEFAULT = new ShazamData(false, false, ShazamPowers.MAX_ENERGY, true);

    public static final Codec<ShazamData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("unlocked", false).forGetter(ShazamData::unlocked),
            Codec.BOOL.optionalFieldOf("transformed", false).forGetter(ShazamData::transformed),
            Codec.FLOAT.optionalFieldOf("energy", ShazamPowers.MAX_ENERGY).forGetter(ShazamData::energy),
            Codec.BOOL.optionalFieldOf("hood_up", true).forGetter(ShazamData::hoodUp)
    ).apply(instance, ShazamData::new));

    public ShazamData withUnlocked(boolean value) {
        return new ShazamData(value, transformed, energy, hoodUp);
    }

    public ShazamData withTransformed(boolean value) {
        return new ShazamData(unlocked, value, energy, hoodUp);
    }

    public ShazamData withEnergy(float value) {
        return new ShazamData(unlocked, transformed, Mth.clamp(value, 0f, ShazamPowers.MAX_ENERGY), hoodUp);
    }

    public ShazamData withHoodUp(boolean value) {
        return new ShazamData(unlocked, transformed, energy, value);
    }
}
