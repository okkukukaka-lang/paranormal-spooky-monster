package com.shazammod.guardian;

import com.shazammod.ShazamItems;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Penjaga Achilles: kebal panah, serangan dari depan ditangkis. Cuma bisa dilukai dari belakang. */
public class UndeadGladiator extends WitherSkeleton implements ShazamGuardian {
    private final GuardianCore core = new GuardianCore(this, BossEvent.BossBarColor.YELLOW,
            ShazamItems.TOTEM_ACHILLES, "hint.shazammod.achilles");
    private int lungeCooldown = 80;
    private int windupTicks;
    private int lungeTicks;
    private int recoverTicks;
    private Vec3 lungeDir = Vec3.ZERO;

    public UndeadGladiator(EntityType<? extends UndeadGladiator> type, Level level) {
        super(type, level);
        this.xpReward = 50;
        equip();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 100.0)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.SCALE, 1.1);
    }

    private void equip() {
        this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.GOLDEN_HELMET));
        this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.GOLDEN_CHESTPLATE));
        this.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.GOLDEN_LEGGINGS));
        this.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.GOLDEN_BOOTS));
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setDropChance(slot, 0f);
        }
    }

    @Override
    public GuardianCore core() {
        return core;
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide) {
            core.tick();
            if (!core.isDormant() && this.isAlive()) {
                tickLunge();
            }
        }
        super.aiStep();
    }

    /** Sesekali menerjang lurus. Sesudahnya dia membeku 1,5 detik: kesempatan memukul punggungnya. */
    private void tickLunge() {
        if (recoverTicks > 0) {
            recoverTicks--;
            return;
        }
        if (windupTicks > 0) {
            windupTicks--;
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.CRIT,
                    this.getX(), this.getY() + 1.0, this.getZ(), 3, 0.3, 0.5, 0.3, 0.05);
            if (windupTicks == 0) {
                lungeTicks = 12;
            }
            return;
        }
        if (lungeTicks > 0) {
            lungeTicks--;
            this.setDeltaMovement(lungeDir.x * 0.8, this.getDeltaMovement().y, lungeDir.z * 0.8);
            for (Player player : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(0.4),
                    p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
                this.doHurtTarget(player);
                lungeTicks = 0;
            }
            if (lungeTicks == 0) {
                recoverTicks = 30;
            }
            return;
        }
        LivingEntity target = this.getTarget();
        if (target != null && --lungeCooldown <= 0) {
            double distance = this.distanceToSqr(target);
            if (distance > 3 * 3 && distance < 12 * 12 && this.hasLineOfSight(target)) {
                Vec3 to = target.position().subtract(this.position());
                lungeDir = new Vec3(to.x, 0, to.z).normalize();
                float yaw = (float) (Mth.atan2(lungeDir.z, lungeDir.x) * (180.0 / Math.PI)) - 90.0f;
                this.setYRot(yaw);
                this.yBodyRot = yaw;
                this.yHeadRot = yaw;
                windupTicks = 10;
                lungeCooldown = 100;
                this.playSound(SoundEvents.WITHER_SKELETON_AMBIENT, 1.5f, 0.6f);
            } else {
                lungeCooldown = 20;
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide) {
            return false;
        }
        if (core.isDormant()) {
            core.wake();
        }
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        if (source.is(DamageTypeTags.IS_PROJECTILE)) {
            parry(source);
            return false;
        }
        Vec3 from = source.getSourcePosition();
        if (from != null) {
            Vec3 facing = Vec3.directionFromRotation(0f, this.yBodyRot);
            Vec3 toAttacker = new Vec3(from.x - this.getX(), 0, from.z - this.getZ()).normalize();
            if (facing.dot(toAttacker) > -0.3) {
                parry(source); // dari depan atau samping: ditangkis
                return false;
            }
            amount *= 1.5f; // tumit Achilles!
        }
        return super.hurt(source, amount);
    }

    private void parry(DamageSource source) {
        this.playSound(SoundEvents.SHIELD_BLOCK, 1f, 0.8f + this.getRandom().nextFloat() * 0.4f);
        ((ServerLevel) this.level()).sendParticles(ParticleTypes.CRIT,
                this.getX(), this.getY() + 1.5, this.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
        if (source.getEntity() instanceof Player player) {
            player.displayClientMessage(Component.translatable("hint.shazammod.achilles")
                    .withStyle(ChatFormatting.YELLOW), true);
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        core.onDeath();
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || core.isDormant() || windupTicks > 0 || lungeTicks > 0 || recoverTicks > 0;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        equip();
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        core.startSeen(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        core.stopSeen(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        core.save(tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        core.load(tag);
    }
}
