package com.shazammod;

import java.util.function.Supplier;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Enam totem dewa dan telur spawn para penjaga. */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ShazamItems {
    private ShazamItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    public static final DeferredItem<Item> TOTEM_SOLOMON = totem("totem_solomon");
    public static final DeferredItem<Item> TOTEM_HERCULES = totem("totem_hercules");
    public static final DeferredItem<Item> TOTEM_ATLAS = totem("totem_atlas");
    public static final DeferredItem<Item> TOTEM_ZEUS = totem("totem_zeus");
    public static final DeferredItem<Item> TOTEM_ACHILLES = totem("totem_achilles");
    public static final DeferredItem<Item> TOTEM_MERCURY = totem("totem_mercury");

    public static final DeferredItem<DeferredSpawnEggItem> SCHOLAR_ZOMBIE_EGG =
            egg("scholar_zombie_spawn_egg", ShazamEntities.SCHOLAR_ZOMBIE, 0x3B2A5A, 0xC9A0FF);
    public static final DeferredItem<DeferredSpawnEggItem> JUNGLE_BRUTE_EGG =
            egg("jungle_brute_spawn_egg", ShazamEntities.JUNGLE_BRUTE, 0x2F5D24, 0xE0B040);
    public static final DeferredItem<DeferredSpawnEggItem> EARTH_GOLEM_EGG =
            egg("earth_golem_spawn_egg", ShazamEntities.EARTH_GOLEM, 0xA4502C, 0x5A2A14);
    public static final DeferredItem<DeferredSpawnEggItem> STORM_STALKER_EGG =
            egg("storm_stalker_spawn_egg", ShazamEntities.STORM_STALKER, 0x2E6FBF, 0xFFE45A);
    public static final DeferredItem<DeferredSpawnEggItem> UNDEAD_GLADIATOR_EGG =
            egg("undead_gladiator_spawn_egg", ShazamEntities.UNDEAD_GLADIATOR, 0x2B2B2B, 0xD4AF37);
    public static final DeferredItem<DeferredSpawnEggItem> MERCURY_SPIRIT_EGG =
            egg("mercury_spirit_spawn_egg", ShazamEntities.MERCURY_SPIRIT, 0xC8D2DC, 0x1E8C96);

    // Kostum Shazam (resep di data/shazammod/recipe/)
    public static final DeferredItem<ArmorItem> SHAZAM_SUIT_HEAD = suit("shazam_suit_head", ArmorItem.Type.HELMET);
    public static final DeferredItem<ArmorItem> SHAZAM_SUIT = suit("shazam_suit", ArmorItem.Type.CHESTPLATE);
    public static final DeferredItem<ArmorItem> SHAZAM_SUIT_LEGS = suit("shazam_suit_legs", ArmorItem.Type.LEGGINGS);
    public static final DeferredItem<ArmorItem> SHAZAM_SUIT_BOOTS = suit("shazam_suit_boots", ArmorItem.Type.BOOTS);

    private static DeferredItem<ArmorItem> suit(String name, ArmorItem.Type type) {
        return ITEMS.register(name, () -> new ArmorItem(ShazamArmor.SHAZAM_SUIT, type,
                new Item.Properties().durability(type.getDurability(37)).rarity(Rarity.EPIC)));
    }

    private static DeferredItem<Item> totem(String name) {
        return ITEMS.registerSimpleItem(name, new Item.Properties()
                .stacksTo(1)
                .rarity(Rarity.EPIC)
                .fireResistant()
                .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true));
    }

    private static DeferredItem<DeferredSpawnEggItem> egg(String name, Supplier<? extends EntityType<? extends Mob>> type,
                                                          int background, int highlight) {
        return ITEMS.register(name, () -> new DeferredSpawnEggItem(type, background, highlight, new Item.Properties()));
    }

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(TOTEM_SOLOMON.get());
            event.accept(TOTEM_HERCULES.get());
            event.accept(TOTEM_ATLAS.get());
            event.accept(TOTEM_ZEUS.get());
            event.accept(TOTEM_ACHILLES.get());
            event.accept(TOTEM_MERCURY.get());
        }
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(SHAZAM_SUIT_HEAD.get());
            event.accept(SHAZAM_SUIT.get());
            event.accept(SHAZAM_SUIT_LEGS.get());
            event.accept(SHAZAM_SUIT_BOOTS.get());
        }
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(SCHOLAR_ZOMBIE_EGG.get());
            event.accept(JUNGLE_BRUTE_EGG.get());
            event.accept(EARTH_GOLEM_EGG.get());
            event.accept(STORM_STALKER_EGG.get());
            event.accept(UNDEAD_GLADIATOR_EGG.get());
            event.accept(MERCURY_SPIRIT_EGG.get());
        }
    }
}
