package com.shazammod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: pemain ini memulai animasi (x, y, z = titik sasaran kalau ada). */
public record ShazamAnimPayload(int entityId, int anim, float x, float y, float z) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamAnimPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("anim"));

    public static final StreamCodec<ByteBuf, ShazamAnimPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShazamAnimPayload::entityId,
            ByteBufCodecs.VAR_INT, ShazamAnimPayload::anim,
            ByteBufCodecs.FLOAT, ShazamAnimPayload::x,
            ByteBufCodecs.FLOAT, ShazamAnimPayload::y,
            ByteBufCodecs.FLOAT, ShazamAnimPayload::z,
            ShazamAnimPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
