package com.shazammod.client.anim;

/**
 * Pose terbang dari fisika gerak (murni Java, gampang diuji). Dihitung tiap tick dari kecepatan
 * dan percepatan sungguhan, lalu dihaluskan dengan pegas teredam (ada sedikit ayunan alami):
 * - melayang: badan condong searah gaya yang dibutuhkan, seperti helikopter (maju = condong ke depan,
 *   bergeser = miring ke samping, mengerem = condong ke belakang);
 * - meluncur: badan sejajar lintasan dengan "hidung" sedikit naik (sudut serang) yang mengecil saat kencang;
 * - menikung: miring ke dalam belokan seperti pesawat, sudut = arctan(percepatan menyamping / gravitasi);
 * - badan menghadap arah lintasan (kepala tetap memandang ke depan kamera);
 * - tangan dan kaki lembam: tertinggal saat dipercepat, terayun ke depan saat mengerem, bergetar kena angin
 *   di kecepatan tinggi;
 * - menjelang tanah sambil turun: badan menegak dan kaki maju untuk mendarat.
 * Sudut badan dalam derajat, tungkai dalam radian.
 */
public final class FlightPose {
    // ======= Angka-angka =======
    private static final double LEAN_G = 0.2;          // condong saat melayang: arctan(percepatan / ini)
    private static final double BANK_G = 0.12;         // menikung: arctan(percepatan menyamping / ini)
    private static final double DRIFT_DRAG = 0.25;     // melayang sambil bergeser: gaya melawan hambatan udara
    private static final double AOA = 11.8;            // sudut serang: AOA / kecepatan² derajat
    private static final float MAX_AOA = 15f;
    private static final float MAX_BANK = 75f;
    private static final float MAX_SIDE = 25f;
    private static final float MAX_YAW = 60f;
    private static final double LEG_LAG = 2.0;         // kaki tertinggal: radian per (blok/tick²)
    private static final double ARM_LAG = 1.2;
    public static final double FLARE_TICKS = 16.0;     // mulai menegak saat tinggal 0,8 detik lagi menyentuh tanah
    // pegas (per tick): badan lebih kaku, tungkai lebih lentur
    private static final float BODY_W = 0.45f, BODY_Z = 0.75f;
    private static final float BANK_W = 0.4f, BANK_Z = 0.7f;
    private static final float LIMB_W = 0.35f, LIMB_Z = 0.45f;

    // ======= Hasil =======
    public float tilt;       // condong ke depan (0 = tegak, 90 = mendatar)
    public float bank;       // menikung (berguling di sumbu panjang badan), + = ke kanan
    public float side;       // miring ke samping saat melayang, + = ke kanan
    public float yaw;        // badan diputar menghadap lintasan (relatif arah pandang)
    public float legSwing;   // + = kaki tertinggal ke belakang
    public float armSwing;   // + = lengan terdorong ke belakang
    public float flutter;    // fase getar angin
    public float flutterAmp; // kuat getar angin (radian)

    private float tiltV, bankV, sideV, yawV, legV, armV;

    /**
     * Seberapa "meluncur" (0 = melayang tegak, 1 = rebah mengikuti lintasan). Naik-turun pelan (spasi/shift),
     * bergeser ke samping, dan mundur pelan tetap tegak; cuma terbang maju atau menukik/menanjak kencang yang rebah.
     */
    public static float soarTarget(double vx, double vy, double vz, float bodyYaw) {
        double horizontal = Math.sqrt(vx * vx + vz * vz);
        double forward = 1.0;
        if (horizontal <= 1.0 && horizontal > 1.0E-4) {
            double yawRad = Math.toRadians(bodyYaw);
            double cos = (vx * -Math.sin(yawRad) + vz * Math.cos(yawRad)) / horizontal;   // searah hadap badan?
            forward = clamp((cos + 0.17) / (0.71 + 0.17), 0.0, 1.0);                       // 45° penuh, 100° nol
        }
        double along = horizontal * forward + Math.max(0.0, Math.abs(vy) - 0.6);
        return (float) clamp((along - 0.25) / 0.9, 0.0, 1.0);
    }

    /** Jarak pandang ke bawah yang perlu dicek untuk ancang-ancang mendarat (blok). */
    public static double groundCheckDistance(double vy) {
        return clamp(-vy * FLARE_TICKS + 2.0, 4.0, 70.0);
    }
    private double svx, svy, svz;   // kecepatan tick lalu
    private double ax, ay, az;      // percepatan (dihaluskan)
    private boolean started;

    /**
     * @param vx,vy,vz   kecepatan tick ini (blok/tick)
     * @param bodyYaw    arah hadap badan (derajat, cara Minecraft: 0 = +Z)
     * @param flight     0-1 sedang terbang
     * @param soar       0-1 meluncur (bukan melayang)
     * @param brake      0-1 sedang mengerem
     * @param ground     jarak ke tanah di bawah (blok)
     */
    public void update(double vx, double vy, double vz, float bodyYaw, float flight, float soar, float brake, double ground) {
        if (!started) {
            svx = vx; svy = vy; svz = vz;
            started = true;
        }
        ax += ((vx - svx) - ax) * 0.5;
        ay += ((vy - svy) - ay) * 0.5;
        az += ((vz - svz) - az) * 0.5;
        svx = vx; svy = vy; svz = vz;

        double speed = Math.sqrt(vx * vx + vy * vy + vz * vz);
        double horizontal = Math.sqrt(vx * vx + vz * vz);
        double yawRad = Math.toRadians(bodyYaw);
        double fx = -Math.sin(yawRad), fz = Math.cos(yawRad);       // depan badan
        double rx = -Math.cos(yawRad), rz = -Math.sin(yawRad);      // kanan badan
        double aF = ax * fx + az * fz;
        double aR = ax * rx + az * rz;
        double vF = vx * fx + vz * fz;
        double vR = vx * rx + vz * rz;

        // 1) Condong (pitch). Melayang: gaya yang dibutuhkan = percepatan + melawan hambatan udara
        double hoverLean = clamp(Math.toDegrees(Math.atan2(aF + DRIFT_DRAG * vF, LEAN_G)), -35.0, 50.0);
        double velocityPitch = Math.toDegrees(Math.atan2(-vy, Math.max(horizontal, 1.0E-4)));
        double aoa = Math.min(MAX_AOA, AOA / Math.max(speed * speed, 1.0E-3));
        double cruiseTilt = clamp(90.0 + velocityPitch, 0.0, 170.0) - aoa;
        // mengerem saat rebah: badan menegak (saat melayang, condong ke belakang sudah dari percepatannya)
        double tiltTarget = Math.max(-35.0, hoverLean + (cruiseTilt - hoverLean) * soar - brake * 40.0 * soar);
        if (vy < -0.15) {
            double ticksToGround = ground / -vy;   // sisa waktu sampai menyentuh tanah
            double k = clamp(1.0 - ticksToGround / FLARE_TICKS, 0.0, 1.0) * Math.min(1.0, -vy / 0.4);
            tiltTarget += (12.0 - tiltTarget) * k;   // menjelang tanah: menegak, kaki maju
        }
        tiltTarget *= flight;

        // 2) Menikung: miring ke dalam belokan seperti pesawat
        double bankTarget = clamp(Math.toDegrees(Math.atan2(aR, BANK_G)), -MAX_BANK, MAX_BANK) * soar * flight;
        // 3) Melayang sambil bergeser: miring ke samping searah gaya
        double sideTarget = clamp(Math.toDegrees(Math.atan2(aR + DRIFT_DRAG * vR, LEAN_G)), -MAX_SIDE, MAX_SIDE)
                * (1.0 - soar) * flight;
        // 4) Badan menghadap arah lintasan saat meluncur
        double yawTarget = 0.0;
        if (horizontal > 0.3) {
            double velYaw = Math.toDegrees(Math.atan2(-vx, vz));
            double delta = wrap(velYaw - bodyYaw);
            double ahead = clamp((Math.cos(Math.toRadians(delta)) + 0.2) / 1.2, 0.0, 1.0);   // mundur: nggak berbalik badan
            yawTarget = clamp(delta, -MAX_YAW, MAX_YAW) * ahead * soar * flight;
        }
        // 5) Tungkai lembam terhadap percepatan searah gerak
        double aT = speed > 1.0E-4 ? (ax * vx + ay * vy + az * vz) / speed : aF;
        double legTarget = clamp(aT * LEG_LAG, -0.6, 0.6) * flight;
        double armTarget = clamp(aT * ARM_LAG, -0.5, 0.5) * flight;
        // 6) Getar angin: makin kencang makin cepat dan kuat
        flutter += (float) (0.5 + speed * 0.45);
        flutterAmp = (float) (flight * Math.pow(Math.min(1.0, speed / 5.0), 1.5) * 0.06);

        float[] s;
        s = spring(tilt, tiltV, (float) tiltTarget, BODY_W, BODY_Z); tilt = s[0]; tiltV = s[1];
        s = spring(bank, bankV, (float) bankTarget, BANK_W, BANK_Z); bank = s[0]; bankV = s[1];
        s = spring(side, sideV, (float) sideTarget, BODY_W, BODY_Z); side = s[0]; sideV = s[1];
        s = spring(yaw, yawV, (float) yawTarget, BODY_W, BODY_Z); yaw = s[0]; yawV = s[1];
        s = spring(legSwing, legV, (float) legTarget, LIMB_W, LIMB_Z); legSwing = s[0]; legV = s[1];
        s = spring(armSwing, armV, (float) armTarget, LIMB_W, LIMB_Z); armSwing = s[0]; armV = s[1];
    }

    /** Pegas teredam (2 langkah per tick, semi-implisit). w = frekuensi (rad/tick), z = redaman. */
    private static float[] spring(float x, float v, float target, float w, float z) {
        for (int i = 0; i < 2; i++) {
            float a = w * w * (target - x) - 2f * z * w * v;
            v += a * 0.5f;
            x += v * 0.5f;
        }
        return new float[] {x, v};
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static double wrap(double deg) {
        deg %= 360.0;
        if (deg >= 180.0) deg -= 360.0;
        if (deg < -180.0) deg += 360.0;
        return deg;
    }
}
