package com.shazammod.client.render;

/**
 * Udara di sekitar jubah dan hood (murni Java): angin sekitar yang arahnya berubah pelan dan berembus,
 * gelombang turbulen yang merambat di kain (makin cepat aliran udara, makin cepat dan kuat kibarannya,
 * seperti bendera), dan bagian kain yang terlindung di belakang badan saat bergerak maju.
 */
public final class CapeAir {
    private CapeAir() {}

    // ======= Angin sekitar (blok/tick; 0,07 = sekitar 1,4 m/detik) =======
    public static final double BREEZE = 0.07;
    public static final double RAIN = 2.2;       // pengali saat hujan
    public static final double THUNDER = 3.5;    // pengali saat badai
    // ======= Kibaran =======
    public static final double FLUTTER_RATE = 1.05;   // kecepatan gelombang: rad per tick per (blok/tick) aliran
    private static final double WAVES = 1.2;          // jumlah gelombang sepanjang kain
    private static final double TURBULENCE_CAP = 2.0; // di atas aliran ini (blok/tick) kibaran nggak makin besar
    // ======= Terlindung di belakang badan =======
    private static final double SHELTER_NEAR = 0.35;  // hambatan udara tepat di belakang punggung
    private static final double SHELTER_DEPTH = 0.7;  // sampai sejauh ini di belakang punggung masih terlindung

    /** Angin sekitar pada waktu t (tick). strength: 0 = di dalam ruangan, 1 = cerah, lebih besar = hujan/badai. */
    public static void ambient(double t, double strength, double[] out) {
        double angle = 0.9 + 0.8 * Math.sin(t * 0.00031) + 0.35 * Math.sin(t * 0.0013 + 2.0);
        double gust = 0.55 + 0.3 * Math.sin(t * 0.021) * Math.sin(t * 0.0067 + 1.3) + 0.15 * Math.sin(t * 0.053 + 0.7);
        double speed = BREEZE * strength * Math.max(0.2, gust);
        out[0] = Math.cos(angle) * speed;
        out[1] = 0.0;
        out[2] = Math.sin(angle) * speed;
    }

    /** Kecepatan aliran udara relatif ke badan (blok/tick): dipakai untuk memajukan fase kibaran. */
    public static double flow(double[] ambient, double bodyVx, double bodyVy, double bodyVz) {
        double fx = ambient[0] - bodyVx, fy = ambient[1] - bodyVy, fz = ambient[2] - bodyVz;
        return Math.sqrt(fx * fx + fy * fy + fz * fz);
    }

    /**
     * Isi angin dan keterbukaan tiap titik kain.
     * @param body       ruang badan (titik nol di kaki, +Y atas, depan = -Z)
     * @param side       arah kanan badan (dunia)
     * @param back       arah belakang badan (dunia)
     * @param phase      fase kibaran (dimajukan pemanggil: FLUTTER_RATE * aliran * dt)
     * @param turbulence kekuatan kibaran (0 = tanpa)
     * @param water      pengali hambatan di dalam air (1 kalau di udara)
     * @param shelter    true untuk jubah (terlindung di belakang punggung)
     */
    public static void fill(ClothSim sim, double[] ambient, double bodyVx, double bodyVy, double bodyVz,
                            HoodShape.Frame body, double[] side, double[] back, double phase,
                            double turbulence, double water, boolean shelter) {
        double fx = ambient[0] - bodyVx, fy = ambient[1] - bodyVy, fz = ambient[2] - bodyVz;
        double flow = Math.sqrt(fx * fx + fy * fy + fz * fz);
        // udara yang datang dari depan (badan maju) meninggalkan "bayangan angin" di belakang punggung
        double frontness = flow > 1.0E-6 ? Math.max(0.0, (fx * back[0] + fy * back[1] + fz * back[2]) / flow) : 0.0;
        double[] p = new double[3];
        for (int i = sim.cols; i < sim.count; i++) {
            int r = i / sim.cols, c = i % sim.cols;
            double along = r / (double) (sim.rows - 1);
            double a = phase - along * WAVES * 2.0 * Math.PI + c * 0.35;   // gelombang merambat ke bawah kain
            double amp = turbulence * Math.min(flow, TURBULENCE_CAP) * along;
            double s1 = Math.sin(a) * amp, s2 = 0.6 * Math.sin(1.37 * a + 1.1) * amp;
            sim.windX[i] = ambient[0] + side[0] * s1 + back[0] * s2;
            sim.windY[i] = ambient[1] + side[1] * s1 + back[1] * s2;
            sim.windZ[i] = ambient[2] + side[2] * s1 + back[2] * s2;
            double e = 1.0;
            if (shelter && frontness > 0.0) {
                p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
                body.toLocal(p);
                boolean behindBody = Math.abs(p[0]) < 0.45 && p[1] > 0.1 && p[1] < 1.6;
                double near = behindBody ? Math.max(0.0, Math.min(1.0, (p[2] - 0.15) / SHELTER_DEPTH)) : 1.0;
                double covered = SHELTER_NEAR + (1.0 - SHELTER_NEAR) * near;
                e = 1.0 - frontness * (1.0 - covered);
            }
            sim.exposure[i] = e * water;
        }
    }
}
