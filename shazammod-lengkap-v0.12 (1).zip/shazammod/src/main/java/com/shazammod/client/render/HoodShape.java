package com.shazammod.client.render;

/**
 * Bentuk dan tabrakan hood (murni Java, gampang diuji).
 * Ruang kepala: titik nol di poros leher, +Y ke atas, depan = -Z, satuan blok.
 * Hood = kain yang pinggirannya (mengelilingi wajah) dipaku; sisanya jatuh, berayun, dan tertiup angin.
 */
public final class HoodShape {
    private HoodShape() {}

    public static final int COLS = 9;            // mengelilingi wajah (dagu kiri -> atas kepala -> dagu kanan)
    public static final int ROWS = 6;            // dari pinggiran wajah ke jahitan belakang
    public static final double RADIUS = 0.345;
    public static final double CENTER_Y = 0.234;
    public static final double FRONT_Z = -0.25;
    public static final double BACK_Z = 0.27;
    // kepala (sedikit dibesarkan)
    public static final double HEAD_HALF = 0.255;
    public static final double HEAD_TOP = 0.49;
    public static final double HEAD_BOTTOM = -0.02;
    // badan, relatif leher
    public static final double TORSO_HALF = 0.30;
    public static final double TORSO_BOTTOM = -0.69;
    public static final double TORSO_TOP = 0.01;
    public static final double TORSO_FRONT = -0.16;
    public static final double TORSO_BACK = 0.22;

    /** Bentuk hood saat dipakai (ruang kepala). */
    public static final double[] REST_X = new double[COLS * ROWS];
    public static final double[] REST_Y = new double[COLS * ROWS];
    public static final double[] REST_Z = new double[COLS * ROWS];
    /** Pinggiran hood saat diturunkan: melingkari belakang leher (ruang badan, relatif leher). */
    public static final double[] DOWN_X = new double[COLS];
    public static final double[] DOWN_Y = new double[COLS];
    public static final double[] DOWN_Z = new double[COLS];

    static {
        for (int r = 0; r < ROWS; r++) {
            double t = r / (double) (ROWS - 1);
            for (int c = 0; c < COLS; c++) {
                double a = (c / (double) (COLS - 1) - 0.5) * Math.toRadians(240.0);
                double sx = Math.sin(a);
                double cy = Math.cos(a);
                int i = r * COLS + c;
                if (t <= 0.75) {
                    double s = t / 0.75;
                    REST_X[i] = RADIUS * sx;
                    REST_Y[i] = CENTER_Y + RADIUS * cy;
                    REST_Z[i] = FRONT_Z + s * (BACK_Z - FRONT_Z);
                } else {
                    double w = (t - 0.75) / 0.25;   // menutup ke jahitan di belakang kepala
                    REST_X[i] = (1 - w) * RADIUS * sx;
                    REST_Y[i] = CENTER_Y + RADIUS * cy * (1 - 0.12 * w) - 0.03 * w;
                    REST_Z[i] = BACK_Z + 0.08 * w;
                }
            }
        }
        for (int c = 0; c < COLS; c++) {
            double ang = (c / (double) (COLS - 1) - 0.5) * Math.PI;
            DOWN_X[c] = 0.27 * Math.sin(ang);
            DOWN_Y[c] = -0.03 + 0.03 * Math.cos(ang);
            DOWN_Z[c] = -0.06 + 0.32 * Math.cos(ang);
        }
    }

    /** Ubah posisi dunia <-> ruang lokal (kepala atau badan), langsung di array {x, y, z}. */
    public interface Frame {
        void toLocal(double[] p);

        void toWorld(double[] p);
    }

    /** Seberapa banyak kain ikut putaran kepala tiap tick (sisanya tertinggal: efek ayunan). Perpindahan selalu diikuti penuh. */
    public static final double FOLLOW_TURN = 0.85;

    /**
     * Bawa kain ikut kepala: perpindahan diikuti penuh (biar berhenti mendadak nggak bikin kain terlempar),
     * putaran diikuti sebagian (biar menoleh bikin hood sedikit berayun). Kecepatan kain ikut digeser.
     * Panggil sesudah snapshot dan sebelum simulate.
     */
    public static void follow(ClothSim sim, Frame before, Frame after, double turn) {
        double[] o0 = {0, 0, 0};
        double[] o1 = {0, 0, 0};
        before.toWorld(o0);
        after.toWorld(o1);
        double mx = o1[0] - o0[0], my = o1[1] - o0[1], mz = o1[2] - o0[2];
        double[] p = new double[3];
        for (int i = COLS; i < sim.count; i++) {
            p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
            before.toLocal(p);
            after.toWorld(p);
            double tx = sim.x[i] + mx, ty = sim.y[i] + my, tz = sim.z[i] + mz;   // cuma pindah
            double dx = tx + (p[0] - tx) * turn - sim.x[i];
            double dy = ty + (p[1] - ty) * turn - sim.y[i];
            double dz = tz + (p[2] - tz) * turn - sim.z[i];
            sim.x[i] += dx; sim.y[i] += dy; sim.z[i] += dz;
            sim.px[i] += dx; sim.py[i] += dy; sim.pz[i] += dz;
        }
    }

    /** Hitungan fisika per langkah kecil: lebih banyak saat hood sedang naik/turun supaya kainnya nggak molor. */
    public static int iterations(double down) {
        return down > 0.02 && down < 0.98 ? 6 : 3;
    }

    /** Seberapa kuat tiap baris ditarik kembali ke bentuk hood (baris 0 = pinggiran wajah, dipaku). */
    private static final double[] MEMORY = {0.0, 0.32, 0.28, 0.24, 0.2, 0.17};
    /** Kain nggak boleh lewat di depan bidang ini (ruang kepala), jadi wajah selalu terlihat. */
    public static final double FACE_GUARD_Z = FRONT_Z + 0.01;

    /** Tabrakan hood: keluar dari kepala dan badan. */
    public static ClothSim.Collider collider(Frame head, Frame neck) {
        double[] p = new double[3];
        return (sim, i) -> {
            p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
            head.toLocal(p);
            if (pushOutOfHead(p)) {
                head.toWorld(p);
                sim.x[i] = p[0]; sim.y[i] = p[1]; sim.z[i] = p[2];
            }
            p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
            neck.toLocal(p);
            if (pushOutOfTorso(p)) {
                neck.toWorld(p);
                sim.x[i] = p[0]; sim.y[i] = p[1]; sim.z[i] = p[2];
            }
        };
    }

    /**
     * Setelah tiap langkah fisika: tarik kain kembali ke bentuk hood (makin turun makin lemah, jadi hood yang
     * diturunkan menggantung bebas), jaga wajah tetap terbuka, lalu cek tabrakan sekali lagi.
     * @param down 0 = dipakai, 1 = diturunkan
     * @param dt   panjang langkah (tick); kekuatan tarikan di MEMORY dihitung per tick
     */
    public static void settle(ClothSim sim, double down, Frame head, ClothSim.Collider collider, double dt) {
        double hold = 1.0 - smooth((down - 0.5) / 0.5);   // bentuk terjaga selama diputar, lalu menggantung bebas
        double[] p = new double[3];
        for (int i = COLS; i < sim.count; i++) {
            double strength = 1.0 - Math.pow(1.0 - MEMORY[i / COLS] * hold, dt);
            if (strength > 0.0) {
                flipped(i, Math.PI * down, p);
                head.toWorld(p);
                sim.x[i] += (p[0] - sim.x[i]) * strength;
                sim.y[i] += (p[1] - sim.y[i]) * strength;
                sim.z[i] += (p[2] - sim.z[i]) * strength;
            }
            if (down < 0.05) {
                p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
                head.toLocal(p);
                if (p[2] < FACE_GUARD_Z && p[1] > HEAD_BOTTOM - 0.1) {
                    p[2] = FACE_GUARD_Z;
                    head.toWorld(p);
                    sim.x[i] = p[0]; sim.y[i] = p[1]; sim.z[i] = p[2];
                }
            }
            collider.collide(sim, i);
        }
    }

    // Hood dilepas dengan diputar ke belakang lewat atas kepala, berporos di dekat tengkuk
    private static final double FLIP_PIVOT_Y = 0.20;
    private static final double FLIP_PIVOT_Z = 0.10;

    private static double smooth(double k) {
        k = Math.max(0.0, Math.min(1.0, k));
        return k * k * (3.0 - 2.0 * k);
    }

    /** Titik ke-i bentuk hood saat diputar ke belakang (ruang kepala). angle 0 = dipakai, PI = terbalik di belakang leher. */
    public static void flipped(int i, double angle, double[] out) {
        double y = REST_Y[i] - FLIP_PIVOT_Y;
        double z = REST_Z[i] - FLIP_PIVOT_Z;
        double c = Math.cos(angle), s = Math.sin(angle);
        out[0] = REST_X[i];
        out[1] = FLIP_PIVOT_Y + y * c - z * s;
        out[2] = FLIP_PIVOT_Z + z * c + y * s;
    }

    /** Posisi dunia paku pinggiran ke-c. down: 0 = dipakai, 1 = diturunkan (sudah diperhalus). */
    public static void rim(int c, double down, Frame head, Frame neck, double[] out) {
        double[] arc = new double[3];
        flipped(c, Math.PI * down, arc);
        head.toWorld(arc);
        out[0] = DOWN_X[c];
        out[1] = DOWN_Y[c];
        out[2] = DOWN_Z[c];
        neck.toWorld(out);
        double w = smooth((down - 0.55) / 0.45);   // di akhir: menempel melingkari leher
        out[0] = arc[0] + (out[0] - arc[0]) * w;
        out[1] = arc[1] + (out[1] - arc[1]) * w;
        out[2] = arc[2] + (out[2] - arc[2]) * w;
    }

    public static ClothSim create() {
        ClothSim sim = new ClothSim(COLS, ROWS, REST_X, REST_Y, REST_Z, 1.0, 0.6, 0.6, 0.5);
        int last = (ROWS - 1) * COLS;
        for (int i = 0; i < COLS / 2; i++) {
            sim.addLink(last + i, last + COLS - 1 - i, 0.0, 1.0); // jahitan belakang menyatu
        }
        return sim;
    }

    /** Dorong titik keluar dari kepala. Nggak pernah ke depan atau ke bawah, jadi wajah nggak pernah tertutup. */
    public static boolean pushOutOfHead(double[] p) {
        double x = p[0], y = p[1], z = p[2];
        if (Math.abs(x) >= HEAD_HALF || y <= HEAD_BOTTOM || y >= HEAD_TOP || Math.abs(z) >= HEAD_HALF) {
            return false;
        }
        double top = HEAD_TOP - y;
        double back = HEAD_HALF - z;
        double left = x + HEAD_HALF;
        double right = HEAD_HALF - x;
        double min = Math.min(Math.min(top, back), Math.min(left, right));
        if (min == top) {
            p[1] = HEAD_TOP;
        } else if (min == back) {
            p[2] = HEAD_HALF;
        } else if (min == left) {
            p[0] = -HEAD_HALF;
        } else {
            p[0] = HEAD_HALF;
        }
        return true;
    }

    /** Dorong titik keluar dari badan (relatif leher): ke belakang punggung, ke atas bahu, atau ke samping. */
    public static boolean pushOutOfTorso(double[] p) {
        double x = p[0], y = p[1], z = p[2];
        if (Math.abs(x) >= TORSO_HALF || y <= TORSO_BOTTOM || y >= TORSO_TOP || z <= TORSO_FRONT || z >= TORSO_BACK) {
            return false;
        }
        double back = TORSO_BACK - z;
        double top = TORSO_TOP - y;
        double left = x + TORSO_HALF;
        double right = TORSO_HALF - x;
        double min = Math.min(Math.min(back, top), Math.min(left, right));
        if (min == back) {
            p[2] = TORSO_BACK;
        } else if (min == top) {
            p[1] = TORSO_TOP;
        } else if (min == left) {
            p[0] = -TORSO_HALF;
        } else {
            p[0] = TORSO_HALF;
        }
        return true;
    }
}
