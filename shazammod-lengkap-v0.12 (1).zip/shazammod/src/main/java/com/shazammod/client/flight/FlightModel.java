package com.shazammod.client.flight;

/**
 * Model gerak terbang Shazam (murni Java, gampang diuji). Satuan: blok dan tick (x20 = per detik).
 * - Dorongan melawan hambatan udara: makin kencang, makin berat menambah kecepatan, lalu mendekati
 *   kecepatan tujuan pelan-pelan tanpa kebablasan.
 * - Belok dibatasi percepatan menyamping maksimum: makin kencang, makin lebar belokannya, dan kecepatan
 *   nggak hilang saat berbelok.
 * - Gravitasi di sepanjang lintasan: menukik menambah kecepatan, menanjak menguranginya.
 * - Lepas W saat kencang: meluncur dan melambat karena hambatan udara; saat pelan: berhenti lalu melayang.
 * - S: rem (hambatan besar).
 */
public final class FlightModel {
    // ======= Angka-angka (blok/tick, blok/tick²) =======
    public static final double CRUISE = 1.4;             // W: ±28 blok/detik
    public static final double TOP_SPEED = 5.0;          // W + sprint penuh: ±100 blok/detik
    public static final double THRUST = 0.18;            // percepatan dorong dari diam
    public static final double BOOST_BUILD = 0.02;       // sprint makin lama makin ngebut
    public static final double TURN_ACCEL = 0.4;         // percepatan menyamping maksimum saat berbelok
    public static final double TURN_RATE_SLOW = 0.5;     // putaran arah maksimum saat pelan (rad/tick)
    public static final double GLIDE_DRAG = 0.008;       // meluncur: hambatan udara (x kecepatan²)
    public static final double GLIDE_FRICTION = 0.012;   // meluncur: hambatan tetap
    public static final double GLIDE_BELOW = 0.8;        // di bawah ini: berhenti lalu melayang
    public static final double HOVER_STOP = 0.06;        // perlambatan saat berhenti melayang
    public static final double BRAKE = 0.2;              // S: perlambatan rem
    public static final double BRAKE_DRAG = 0.012;
    public static final double PATH_GRAVITY = 0.06;      // menukik/menanjak
    public static final double VERTICAL = 0.55;          // spasi/shift
    public static final double STRAFE = 0.6;             // A/D di kecepatan rendah
    public static final double STRAFE_BELOW = 2.0;
    public static final double MAX_SPEED = TOP_SPEED * 1.1;

    public double vx, vy, vz;
    public double boost;

    public double speed() {
        return Math.sqrt(vx * vx + vy * vy + vz * vz);
    }

    public void set(double x, double y, double z) {
        vx = x; vy = y; vz = z;
    }

    public void reset() {
        vx = 0; vy = 0; vz = 0; boost = 0;
    }

    /**
     * Satu tick kendali terbang.
     * @param forward  W (+1) / S (-1)
     * @param strafe   kiri (+1) / kanan (-1), seperti input Minecraft
     * @param vertical spasi (+1) / shift (-1)
     * @param look     arah pandangan (vektor satuan)
     */
    public void step(double forward, double strafe, int vertical, boolean sprint,
                     double lookX, double lookY, double lookZ) {
        double speed = speed();
        double fl = Math.sqrt(lookX * lookX + lookZ * lookZ);
        double flatX = fl > 1.0E-6 ? lookX / fl : 0.0, flatZ = fl > 1.0E-6 ? lookZ / fl : 0.0;
        double rightX = -flatZ, rightZ = flatX;

        // Kecepatan tujuan dari tombol
        double tx = 0, ty = 0, tz = 0;
        boolean braking = false;
        if (forward > 0.01) {
            boost = sprint ? Math.min(1.0, boost + BOOST_BUILD + boost * 0.03) : Math.max(0.0, boost - 0.05);
            double s = (CRUISE + (TOP_SPEED - CRUISE) * boost) * forward;
            tx = lookX * s; ty = lookY * s; tz = lookZ * s;
        } else if (forward < -0.01 && speed > 0.4) {
            boost = 0.0;
            braking = true;
        } else {
            boost = Math.max(0.0, boost - 0.05);
            if (forward < -0.01) {
                tx = -flatX * 0.4; tz = -flatZ * 0.4;   // mundur pelan
            }
        }
        if (speed < STRAFE_BELOW && Math.abs(strafe) > 0.01) {
            tx += rightX * -strafe * STRAFE;
            tz += rightZ * -strafe * STRAFE;
        }
        if (vertical != 0) {
            ty += vertical * VERTICAL;
        }
        double target = Math.sqrt(tx * tx + ty * ty + tz * tz);

        // 1) Arah: berputar menuju arah tujuan, dibatasi percepatan menyamping (kencang = belokan lebar)
        double dx, dy, dz;
        double align = 1.0;
        if (speed > 1.0E-4) {
            dx = vx / speed; dy = vy / speed; dz = vz / speed;
        } else if (target > 1.0E-4) {
            dx = tx / target; dy = ty / target; dz = tz / target;
        } else {
            dx = 0; dy = 0; dz = 0;
        }
        if (target > 1.0E-4) {
            double gx = tx / target, gy = ty / target, gz = tz / target;
            if (speed < 0.05) {
                dx = gx; dy = gy; dz = gz;   // dari diam: langsung ke arah tujuan
            } else {
                double maxTurn = Math.min(TURN_RATE_SLOW, TURN_ACCEL / speed);
                double[] d = rotateToward(dx, dy, dz, gx, gy, gz, maxTurn);
                dx = d[0]; dy = d[1]; dz = d[2];
                align = Math.max(0.3, dx * gx + dy * gy + dz * gz);
            }
        }

        // 2) Besar kecepatan
        double next;
        if (braking) {
            next = Math.max(0.0, speed - (BRAKE + BRAKE_DRAG * speed * speed));
        } else if (target > speed) {
            double r = speed / target;
            next = Math.min(target, speed + THRUST * (1.0 - r * r) * align);   // dorongan dikurangi hambatan udara
        } else if (speed > GLIDE_BELOW) {
            next = Math.max(target, speed - (GLIDE_DRAG * speed * speed + GLIDE_FRICTION));   // meluncur
        } else {
            next = Math.max(target, speed - HOVER_STOP);   // berhenti lalu melayang
        }

        // 3) Gravitasi di sepanjang lintasan (nggak berlaku saat melayang pelan)
        double moving = smoothstep((speed - 0.3) / 0.7);
        next -= PATH_GRAVITY * dy * moving;
        next = Math.max(0.0, Math.min(MAX_SPEED, next));

        vx = dx * next; vy = dy * next; vz = dz * next;
    }

    /** Putar vektor satuan a menuju b, paling banyak maxAngle radian. */
    static double[] rotateToward(double ax, double ay, double az, double bx, double by, double bz, double maxAngle) {
        double cos = Math.max(-1.0, Math.min(1.0, ax * bx + ay * by + az * bz));
        double angle = Math.acos(cos);
        if (angle <= maxAngle || angle < 1.0E-6) {
            return new double[] {bx, by, bz};
        }
        // sumbu putar = a x b. Kalau berlawanan arah (hampir) persis: belok menyamping lewat sumbu tegak,
        // kecuali sedang terbang tegak lurus (baru lewat sumbu mendatar).
        double kx = ay * bz - az * by, ky = az * bx - ax * bz, kz = ax * by - ay * bx;
        double kl = Math.sqrt(kx * kx + ky * ky + kz * kz);
        if (kl < 1.0E-3) {
            double ux = 0, uy = 1, uz = 0;
            if (Math.abs(ay) > 0.9) {
                ux = 1; uy = 0;
            }
            double d = ux * ax + uy * ay + uz * az;
            kx = ux - d * ax; ky = uy - d * ay; kz = uz - d * az;
            kl = Math.sqrt(kx * kx + ky * ky + kz * kz);
        }
        kx /= kl; ky /= kl; kz /= kl;
        double c = Math.cos(maxAngle), s = Math.sin(maxAngle);
        double dot = kx * ax + ky * ay + kz * az;
        double cx = ky * az - kz * ay, cy = kz * ax - kx * az, cz = kx * ay - ky * ax;
        return new double[] {
                ax * c + cx * s + kx * dot * (1 - c),
                ay * c + cy * s + ky * dot * (1 - c),
                az * c + cz * s + kz * dot * (1 - c)};
    }

    private static double smoothstep(double k) {
        k = Math.max(0.0, Math.min(1.0, k));
        return k * k * (3.0 - 2.0 * k);
    }
}
