package com.shazammod.client.render;

/**
 * Simulasi kain dengan langkah kecil tetap (Verlet): titik-titik grid yang disambung tali.
 * Baris paling atas dipaku. Gaya yang bekerja seperti kain sungguhan:
 * - gravitasi;
 * - hambatan udara: angin mendorong permukaan kain sesuai sudutnya (kuadrat kecepatan, dihitung implisit
 *   supaya tetap stabil walau terbang 100 blok/detik), plus gesekan udara kecil searah permukaan;
 * - redaman kecil di dalam kain.
 * Tali panjang (long-range attachment) dari tiap titik ke paku-paku di atas menjaga kain nggak pernah
 * lebih panjang dari ukuran aslinya, tanpa perlu "menyeret" kain ikut badan secara kaku.
 * Murni Java supaya gampang diuji.
 */
public final class ClothSim {
    /** Dipanggil tiap iterasi untuk menjauhkan kain dari badan dan lantai. */
    public interface Collider {
        void collide(ClothSim sim, int index);
    }

    public final int cols;
    public final int rows;
    public final int count;
    public final double[] x, y, z;      // posisi sekarang
    public final double[] px, py, pz;   // posisi langkah lalu (kecepatan Verlet)
    public final double[] rx, ry, rz;   // posisi sebelum langkah terakhir (buat interpolasi render)
    /** Kecepatan udara di tiap titik (blok/tick), diisi pemanggil sebelum melangkah. */
    public final double[] windX, windY, windZ;
    /** Pengali hambatan udara tiap titik: 1 = terbuka, lebih kecil = terlindung, lebih besar = di dalam air. */
    public final double[] exposure;
    private final double[] nx, ny, nz;  // normal permukaan, dihitung tiap langkah

    private final int[] linkA;
    private final int[] linkB;
    private final double[] rest;
    private final double[] stiffness;
    private final boolean[] vertical;
    private int links;
    /** Batas regangan sambungan tegak (1,06 = paling panjang 6% lebih dari ukuran asli). */
    public double maxStretch = 1.06;

    private int[] tetherA = new int[0];
    private int[] tetherB = new int[0];
    private double[] tetherLength = new double[0];
    private int tethers;

    private boolean ready;
    private double cx, cy, cz;

    public ClothSim(int cols, int rows, double[] restX, double[] restY, double[] restZ) {
        this(cols, rows, restX, restY, restZ, 1.0, 0.5, 0.3, 0.2);
    }

    /**
     * @param shear    kekakuan sambungan silang (menahan kain miring)
     * @param bendRows kekakuan menekuk searah baris (makin besar makin kaku)
     * @param bendCols kekakuan menekuk searah kolom
     */
    public ClothSim(int cols, int rows, double[] restX, double[] restY, double[] restZ,
                    double structural, double shear, double bendRows, double bendCols) {
        this.cols = cols;
        this.rows = rows;
        this.count = cols * rows;
        x = new double[count]; y = new double[count]; z = new double[count];
        px = new double[count]; py = new double[count]; pz = new double[count];
        rx = new double[count]; ry = new double[count]; rz = new double[count];
        windX = new double[count]; windY = new double[count]; windZ = new double[count];
        exposure = new double[count];
        java.util.Arrays.fill(exposure, 1.0);
        nx = new double[count]; ny = new double[count]; nz = new double[count];
        int max = count * 9;
        linkA = new int[max];
        linkB = new int[max];
        rest = new double[max];
        stiffness = new double[max];
        vertical = new boolean[max];
        // Urutan baris atas -> bawah supaya tarikan dari bahu merambat dalam satu putaran
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                if (c + 1 < cols) link(i, i + 1, structural, restX, restY, restZ);
                if (r + 1 < rows) {
                    link(i, i + cols, structural, restX, restY, restZ);
                    vertical[links - 1] = true;
                }
                if (r + 1 < rows && c + 1 < cols) {
                    link(i, i + cols + 1, shear, restX, restY, restZ);
                    link(i + 1, i + cols, shear, restX, restY, restZ);
                }
                if (r + 2 < rows) link(i, i + 2 * cols, bendRows, restX, restY, restZ);
                if (c + 2 < cols) link(i, i + 2, bendCols, restX, restY, restZ);
            }
        }
    }

    private void link(int a, int b, double k, double[] restX, double[] restY, double[] restZ) {
        double dx = restX[b] - restX[a], dy = restY[b] - restY[a], dz = restZ[b] - restZ[a];
        addLink(a, b, Math.sqrt(dx * dx + dy * dy + dz * dz), k);
    }

    /** Sambungan tambahan, misalnya jahitan belakang hood. */
    public void addLink(int a, int b, double restLength, double k) {
        linkA[links] = a;
        linkB[links] = b;
        rest[links] = restLength;
        stiffness[links] = k;
        links++;
    }

    /**
     * Tali panjang: tiap titik nggak boleh lebih jauh dari tiap paku daripada jarak diamnya.
     * Cocok untuk kain yang bentuk diamnya rata (jubah).
     */
    public void addTethers(double[] restX, double[] restY, double[] restZ) {
        int n = (count - cols) * cols;
        tetherA = new int[n];
        tetherB = new int[n];
        tetherLength = new double[n];
        tethers = 0;
        for (int i = cols; i < count; i++) {
            for (int j = 0; j < cols; j++) {
                double dx = restX[i] - restX[j], dy = restY[i] - restY[j], dz = restZ[i] - restZ[j];
                tetherA[tethers] = i;
                tetherB[tethers] = j;
                tetherLength[tethers] = Math.sqrt(dx * dx + dy * dy + dz * dz);
                tethers++;
            }
        }
    }

    public boolean isReady() {
        return ready;
    }

    /** Jarak pusat paku sekarang ke pusat paku langkah lalu (buat mendeteksi teleport). */
    public double distanceToCenter(double x0, double y0, double z0) {
        double dx = x0 - cx, dy = y0 - cy, dz = z0 - cz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Susun ulang kain ke bentuk tertentu (posisi dunia), diam. */
    public void reset(double[] wx, double[] wy, double[] wz) {
        System.arraycopy(wx, 0, x, 0, count); System.arraycopy(wx, 0, px, 0, count); System.arraycopy(wx, 0, rx, 0, count);
        System.arraycopy(wy, 0, y, 0, count); System.arraycopy(wy, 0, py, 0, count); System.arraycopy(wy, 0, ry, 0, count);
        System.arraycopy(wz, 0, z, 0, count); System.arraycopy(wz, 0, pz, 0, count); System.arraycopy(wz, 0, rz, 0, count);
        cx = 0; cy = 0; cz = 0;
        for (int c = 0; c < cols; c++) {
            cx += wx[c]; cy += wy[c]; cz += wz[c];
        }
        cx /= cols; cy /= cols; cz /= cols;
        ready = true;
    }

    /** Simpan posisi sebelum langkah ini (buat interpolasi render). */
    public void snapshot() {
        System.arraycopy(x, 0, rx, 0, count);
        System.arraycopy(y, 0, ry, 0, count);
        System.arraycopy(z, 0, rz, 0, count);
    }

    /** Satu langkah: snapshot lalu simulate. */
    public void step(double dt, double[] anchorX, double[] anchorY, double[] anchorZ, double gravity,
                     double dragNormal, double dragTangent, double damping, int iterations, double scale, Collider collider) {
        snapshot();
        simulate(dt, anchorX, anchorY, anchorZ, gravity, dragNormal, dragTangent, damping, iterations, scale, collider);
    }

    /**
     * Satu langkah tanpa snapshot (kalau kain sudah digeser dulu, misalnya ikut putaran kepala).
     * @param dt          panjang langkah (tick); kecepatan dalam blok/tick
     * @param gravity     percepatan jatuh (blok/tick²)
     * @param dragNormal  hambatan udara tegak lurus kain (per blok)
     * @param dragTangent gesekan udara searah permukaan kain (per blok)
     * @param damping     redaman di dalam kain (per tick)
     * @param scale       ukuran badan (kain ikut membesar)
     */
    public void simulate(double dt, double[] anchorX, double[] anchorY, double[] anchorZ, double gravity,
                         double dragNormal, double dragTangent, double damping, int iterations, double scale,
                         Collider collider) {
        computeNormals();
        double keep = Math.exp(-damping * dt);
        double ncx = 0, ncy = 0, ncz = 0;
        for (int c = 0; c < cols; c++) {
            px[c] = x[c]; py[c] = y[c]; pz[c] = z[c];
            x[c] = anchorX[c]; y[c] = anchorY[c]; z[c] = anchorZ[c];
            ncx += x[c]; ncy += y[c]; ncz += z[c];
        }
        for (int i = cols; i < count; i++) {
            double vx = (x[i] - px[i]) / dt * keep;
            double vy = (y[i] - py[i]) / dt * keep - gravity * dt;
            double vz = (z[i] - pz[i]) / dt * keep;
            double e = exposure[i];
            if (e > 0.0) {
                // kecepatan kain relatif terhadap udara, dipecah: tegak lurus kain dan searah permukaan
                double ux = vx - windX[i], uy = vy - windY[i], uz = vz - windZ[i];
                double vn = ux * nx[i] + uy * ny[i] + uz * nz[i];
                double tx = ux - vn * nx[i], ty = uy - vn * ny[i], tz = uz - vn * nz[i];
                double vn2 = vn / (1.0 + dragNormal * e * Math.abs(vn) * dt);
                double tf = 1.0 / (1.0 + dragTangent * e * Math.sqrt(tx * tx + ty * ty + tz * tz) * dt);
                vx = windX[i] + tx * tf + vn2 * nx[i];
                vy = windY[i] + ty * tf + vn2 * ny[i];
                vz = windZ[i] + tz * tf + vn2 * nz[i];
            }
            px[i] = x[i]; py[i] = y[i]; pz[i] = z[i];
            x[i] += vx * dt; y[i] += vy * dt; z[i] += vz * dt;
        }
        for (int it = 0; it < iterations; it++) {
            for (int k = 0; k < links; k++) {
                satisfy(k, scale);
            }
            for (int k = 0; k < tethers; k++) {
                tether(k, scale);
            }
            if (collider != null) {
                for (int i = cols; i < count; i++) {
                    collider.collide(this, i);
                }
            }
        }
        // Terakhir: tali panjang dan batas regangan (kain nggak molor), lalu tabrakan (nggak menembus badan)
        for (int k = 0; k < tethers; k++) {
            tether(k, scale);
        }
        for (int k = 0; k < links; k++) {
            if (vertical[k]) {
                limit(k, scale);
            }
        }
        if (collider != null) {
            for (int i = cols; i < count; i++) {
                collider.collide(this, i);
            }
        }
        cx = ncx / cols; cy = ncy / cols; cz = ncz / cols;
    }

    private void computeNormals() {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                int left = r * cols + Math.max(0, c - 1), right = r * cols + Math.min(cols - 1, c + 1);
                int up = Math.max(0, r - 1) * cols + c, down = Math.min(rows - 1, r + 1) * cols + c;
                double tx = x[right] - x[left], ty = y[right] - y[left], tz = z[right] - z[left];
                double bx = x[down] - x[up], by = y[down] - y[up], bz = z[down] - z[up];
                double ax = ty * bz - tz * by, ay = tz * bx - tx * bz, az = tx * by - ty * bx;
                double len = Math.sqrt(ax * ax + ay * ay + az * az);
                if (len < 1.0E-9) {
                    nx[i] = 0; ny[i] = 0; nz[i] = 0;   // nggak jelas arahnya: tanpa dorongan angin tegak lurus
                } else {
                    nx[i] = ax / len; ny[i] = ay / len; nz[i] = az / len;
                }
            }
        }
    }

    private void satisfy(int k, double scale) {
        int a = linkA[k], b = linkB[k];
        boolean pinA = a < cols, pinB = b < cols;
        if (pinA && pinB) {
            return;
        }
        double dx = x[b] - x[a], dy = y[b] - y[a], dz = z[b] - z[a];
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 1.0E-9) {
            return;
        }
        double diff = (d - rest[k] * scale) / d * stiffness[k];
        if (pinA) {
            x[b] -= dx * diff; y[b] -= dy * diff; z[b] -= dz * diff;
        } else if (pinB) {
            x[a] += dx * diff; y[a] += dy * diff; z[a] += dz * diff;
        } else {
            double h = diff * 0.5;
            x[a] += dx * h; y[a] += dy * h; z[a] += dz * h;
            x[b] -= dx * h; y[b] -= dy * h; z[b] -= dz * h;
        }
    }

    /** Sambungan tegak yang terlalu panjang dipendekkan dari atas ke bawah (titik bawah ditarik ke atas). */
    private void limit(int k, double scale) {
        int a = linkA[k], b = linkB[k];
        double dx = x[b] - x[a], dy = y[b] - y[a], dz = z[b] - z[a];
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double max = rest[k] * scale * maxStretch;
        if (d > max) {
            double f = max / d;
            x[b] = x[a] + dx * f;
            y[b] = y[a] + dy * f;
            z[b] = z[a] + dz * f;
        }
    }

    private void tether(int k, double scale) {
        int i = tetherA[k], j = tetherB[k];
        double dx = x[i] - x[j], dy = y[i] - y[j], dz = z[i] - z[j];
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double max = tetherLength[k] * scale;
        if (d > max) {
            double f = max / d;
            x[i] = x[j] + dx * f;
            y[i] = y[j] + dy * f;
            z[i] = z[j] + dz * f;
        }
    }
}
